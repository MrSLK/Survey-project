-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 18, 2020 at 10:53 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `surname` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `contactNum` bigint(10) DEFAULT NULL,
  `dates` varchar(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `food` enum('Pizza','Pasta','papwors','Chicken_stir_fry','beefStirFry','other') DEFAULT NULL,
  `eatOut` enum('strongAgree','agree','neutral','disagree','strongDisagree') DEFAULT NULL,
  `movies` enum('strongAgree','agree','neutral','disagree','strongDisagree') DEFAULT NULL,
  `tv` enum('strongAgree','agree','neutral','disagree','strongDisagree') DEFAULT NULL,
  `radio` enum('strongAgree','agree','neutral','disagree','strongDisagree') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `surname`, `first_name`, `contactNum`, `dates`, `age`, `food`, `eatOut`, `movies`, `tv`, `radio`) VALUES
(15, 'Manamela', 'Kgabo', 751436523, '2020-02-06', 22, 'Pasta', 'agree', 'neutral', 'agree', 'strongDisagree'),
(14, 'Koenaite', 'Shiba', 795813108, '2020-01-26', 22, 'Pizza', 'strongAgree', 'strongAgree', 'strongAgree', 'strongAgree');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
